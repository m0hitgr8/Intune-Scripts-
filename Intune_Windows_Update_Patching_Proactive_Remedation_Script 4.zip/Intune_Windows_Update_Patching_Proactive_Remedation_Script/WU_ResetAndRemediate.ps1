﻿#﻿<#
#.SYNOPSIS
#This script remediates Windows Update compliance by:
#- Deleting specific Windows Update registry keys
#- Removing Group Policy Registry.pol file
#- Forcing group policy update
#- Restarting Windows Update service
#- Logging all actions for auditing purposes
#>

$error.Clear()
Clear
$ErrorActionPreference = 'Stop'
Set-ExecutionPolicy -ExecutionPolicy 'ByPass' -Force -ErrorAction 'Stop'

# Initialize Logging
$LogPath = "C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\Intune_Patching_Compliance.log"
$LogFolder = Split-Path $LogPath

# Check if folder exists, if not create it
if (-not (Test-Path $LogFolder)) {
    Try {
        New-Item -Path $LogFolder -ItemType Directory -Force | Out-Null
        Write-Host "Created log folder: $LogFolder"
    } Catch {
        Write-Host "Failed to create log folder: $LogFolder. Error: $_"
        Exit 1
    }
}

Function Write-Log {
    Param([string]$Message)
    "$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss')) - $Message" | Out-File -FilePath $LogPath -Append
}

Write-Log "====================== Running WU_Reset And Remediate Script $(Get-Date -Format 'yyyy/MM/dd') ==================="

# Delete the registry key
$registryPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
Try {
    if (Test-Path $registryPath) {
        Remove-Item -Path $registryPath -Recurse -Force
        Write-Log "Deleted registry key: $registryPath"
    } else {
        Write-Log "Registry key not found: $registryPath"
    }
} Catch {
    Write-Log "Error deleting registry key $($registryPath): $_"
}

# Delete the file
$filePath = "C:\Windows\System32\GroupPolicy\Machine\Registry.pol"
Try {
    if (Test-Path $filePath) {
        Remove-Item -Path $filePath -Force
        Write-Log "Deleted file: $filePath"
    } else {
        Write-Log "File not found: $filePath"
    }
} Catch {
    Write-Log "Error deleting file $($filePath): $_"
}

# Run gpupdate /force
Try {
    Write-Log "Running gpupdate /force..."
    gpupdate /force | Out-Null
    Write-Log "gpupdate /force completed successfully"
} Catch {
    Write-Log "Error running gpupdate /force: $_"
}

# Restart the Windows Update service
Try {
    Write-Log "Restarting Windows Update service..."
    Restart-Service -Name wuauserv -Force
    Write-Log "Windows Update service restarted successfully"
} Catch {
    Write-Log "Error restarting Windows Update service: $_"
}

Write-Log "====================== WU_Reset And Remediate Script Completed $(Get-Date -Format 'yyyy/MM/dd HH:mm:ss') ==================="
