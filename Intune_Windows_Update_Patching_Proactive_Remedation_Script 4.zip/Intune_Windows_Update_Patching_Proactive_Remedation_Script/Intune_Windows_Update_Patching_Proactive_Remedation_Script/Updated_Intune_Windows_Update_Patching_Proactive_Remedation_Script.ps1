﻿﻿
#.SYNOPSIS
#Intune Windows Update Patching Remediation Scrip >

#.DESCRIPTION
#Intune Windows Update Patching Remediation Scrip >

#.Demo
#YouTube video link--> https://www.youtube.com/@ChanderManiPandey

#.OUTPUTS
#Script will install latest Security Update >

#.Log Location 
#C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\Intune_Patching_Compliance_Log_Current_Date


#.NOTES
# Version            :   1.1
# Author             :   Chander Mani Pandey
# Creation Date      :   12 July 2025
 
# Find the author on:
   
# YouTube            :   https://www.youtube.com/@chandermanipandey8763  
# Twitter            :   https://twitter.com/Mani_CMPandey  
# LinkedIn           :   https://www.linkedin.com/in/chandermanipandey  
# BlueSky            :   https://bsky.app/profile/chandermanipandey.bsky.social
# GitHub             :   https://github.com/ChanderManiPandey2022

# Version            : 1.2
                      #Fixed: Script stuck to install PSWindowsUpdate module.Added logic to Check and install if NuGet is missing or outdated.
                      #Added log to find machine is Intune managed and Defer Quality Updates Period InDays.
#>

$error.Clear() 
Clear
$ErrorActionPreference = 'Stop' 
Set-ExecutionPolicy -ExecutionPolicy 'ByPass' -Force -ErrorAction 'Stop'

# Initialize Logging
$LogPath = "C:\ProgramData\Microsoft\IntuneManagementExtension\Logs\Intune_Patching_Compliance.log"         
Function Write-Log {
    Param([string]$Message)
    "$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss')) - $Message" | Out-File -FilePath $LogPath  -Append
}
Write-Log "====================== Running Intune Patching Remediation Script $(Get-Date -Format 'yyyy/MM/dd') ==================="

$HostName = hostname
$ESP = Get-Process -ProcessName CloudExperienceHostBroker -ErrorAction SilentlyContinue
If ($ESP) {
    Write-Log "Windows Autopilot ESP Running"
    Exit 1 
} Else {
    Write-Log "Windows Autopilot ESP Not Running"
}

Write-Log "Checking Machine:- $HostName OS Build Version"

$OSInfo = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
$currentBuildMajor = $OSInfo.CurrentBuild
$currentMajorVersion = "$($OSInfo.CurrentMajorVersionNumber).$($OSInfo.CurrentMinorVersionNumber)"
$currentFullBuild = "$currentMajorVersion.$($OSInfo.CurrentBuild).$($OSInfo.UBR)"
Write-Log "Current OS Build version: $currentFullBuild"

# Windows Update Source Location"
$MUSM = New-Object -ComObject "Microsoft.Update.ServiceManager"
$Output = $MUSM.Services | Where-Object { $_.IsDefaultAUService -eq $true }

if ($null -ne $Output) {
    $Patching_Source_Location = switch ($Output.Name) {
        "Windows Server Update Service" { "SCCM / WSUS" }
        "Windows Update"                { "Windows Update" }
        "Microsoft Update"             { "Intune / GPO" }
        default                        { $Output.Name }
    }
} else {
    $Patching_Source_Location = "Unknown or Not Available"
}

Write-log "Machine Windows Update Source = $Patching_Source_Location"
Write-log "Information: For Intune managed devices, Windows Update Source = Microsoft Update"
Write-log "Information: For SCCM managed devices, Windows Update Source = SCCM / WSUS"

$LastReboot = (Get-CimInstance Win32_OperatingSystem).LastBootUpTime
Write-Log "Machine Last Reboot Time: $LastReboot"

$Disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
$TotalSpaceGB = [math]::Round($Disk.Size / 1GB, 2)
$FreeSpaceGB  = [math]::Round($Disk.FreeSpace / 1GB, 2)
Write-Log "Machine Total C: Drive Space: $TotalSpaceGB GB"
Write-Log "Machine Free  C: Drive Space: $FreeSpaceGB GB"
Write-Log "Information: If disk space is less than 5 GB free, it might impact patch installation."


# Checking Windows Update
# Change Windows Update service (wuauserv) startup type to Manual using WMI
Write-Log "Checking Windows Update related services and their startup types..."

$service = Get-WmiObject -Class Win32_Service -Filter "Name='wuauserv'"
if ($service.StartMode -ne 'Manual') {
    Write-Log "Changing startup type to Manual for Windows Update service (wuauserv)"
    $result = $service.ChangeStartMode("Manual")
    
    if ($result.ReturnValue -eq 0) {
        Write-Log "Windows Update service (wuauserv) successfully changed to Manual."
    } else {
        Write-Log "Failed to change startup type. Error code: $($result.ReturnValue)" 
    }
} else {
    Write-Log "Windows Update service (wuauserv) is already set to Manual."
}

# Checking Microsoft Account Sign-in Assistant Service
$ServiceName = 'wlidsvc'
$ServiceType = (Get-Service -Name $ServiceName).StartType
Write-Log "Microsoft Account Sign-in Assistant Service startup type is '$ServiceType'"
if ([string]$ServiceType -ne 'Manual') {
    Write-Log "Startup type for Microsoft Account Sign-in Assistant is not Manual. Consider setting it to Manual."
    # Set-Service -Name $ServiceName -StartupType Manual
}

# Checking Update Orchestrator Service
$ServiceName = 'UsoSvc'
$ServiceType = (Get-Service -Name $ServiceName).StartType
if ($ServiceType) {
    Write-Log "Update Orchestrator Service startup type is '$ServiceType'"
    if ([string]$ServiceType -ne 'Automatic') {
        Write-Log "Startup type for Update Orchestrator Service is not Automatic. Consider setting it to Automatic."
        # Set-Service -Name $ServiceName -StartupType Automatic
    }
    }

Function Get-LatestWindowsUpdateInfo {
    $currentBuild = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').CurrentBuild
    $osBuildMajor = $currentBuild.Substring(0, 1)

    $updateUrl = if ($osBuildMajor -eq "2") {
        "https://aka.ms/Windows11UpdateHistory"
    } else {
        "https://support.microsoft.com/en-us/help/4043454"
    }

    $response = if ($PSVersionTable.PSVersion.Major -ge 6) {
        Invoke-WebRequest -Uri $updateUrl -ErrorAction Stop
    } else {
        Invoke-WebRequest -Uri $updateUrl -UseBasicParsing -ErrorAction Stop
    }

    $updateLinks = $response.Links | Where-Object {
        $_.outerHTML -match "supLeftNavLink" -and
        $_.outerHTML -match "KB" -and
        $_.outerHTML -notmatch "Preview" -and
        $_.outerHTML -notmatch "Out-of-band"
    }

    $latest = $updateLinks | Where-Object {
        $_.outerHTML -match $currentBuild
    } | Select-Object -First 1

    if ($latest) {
        $title = $latest.outerHTML.Split('>')[1].Replace('</a','').Replace('&#x2014;', ' - ')
        $kbId  = "KB" + $latest.href.Split('/')[-1]

        [PSCustomObject]@{
            LatestUpdate_Title = $title
            LatestUpdate_KB    = $kbId
        }
    } else {
        Write-Log "No update found for current build."
        Write-Host "No update found for current build."
        Exit 1
    }
}

# ======================== Update Info & Parsing Fix =======================
$latestUpdateInfo = Get-LatestWindowsUpdateInfo
write-log $latestUpdateInfo
$buildStringRaw = ($latestUpdateInfo.LatestUpdate_Title -split 'OS Build ')[-1] -replace '[\)\(]', ''
$matchedBuild = ($buildStringRaw -split 'and') | ForEach-Object { $_.Trim() } | Where-Object { $_ -like "$currentBuildMajor*" } | Select-Object -First 1

if (-not $matchedBuild) {
    Write-Log "Could not find matching build from update title: $buildStringRaw"
    Write-Host "Could not find matching build from update title: $buildStringRaw"
    Exit 1
}

try {
    $latestBuild = [version]"10.0.$matchedBuild"
} catch {
    Write-Log "Failed to parse latest build: $matchedBuild"
    Write-Host "Failed to parse latest build: $matchedBuild"
    Exit 1
}

try {
    $currentBuild = [version]"10.0.$($OSInfo.CurrentBuild).$($OSInfo.UBR)"
} catch {
    Write-Log "Failed to get current build or UBR"
    Write-Host "Failed to get current build or UBR"
    Exit 1
}

Write-Log "Latest Available Build: $latestBuild"
Write-Log "Current Machine Build: $currentBuild"

if ($currentBuild -ge $latestBuild) {
    Write-Log "Machine is Compliant. Current Build: $currentBuild, Required: $latestBuild"
    Write-Log "No remediation needed. Exiting with Compliant (success) status."
    Write-Host "Machine is Compliant. Current Build: $currentBuild, Required: $latestBuild"
    Exit 0
}

# ===================== Update Required ===========================
Write-Log "Machine is NOT Compliant."
Write-Log "$($latestUpdateInfo.LatestUpdate_Title) update required"

$updateTitle = $latestUpdateInfo.LatestUpdate_Title
$dateString = $updateTitle -split ' -' | Select-Object -First 1
# Convert to DateTime
$updateDate = [datetime]::ParseExact($dateString, 'MMMM d, yyyy', $null)

# Define the registry path and value name
$regPath = "HKLM:\SOFTWARE\Microsoft\PolicyManager\current\device\Update"
$valueName = "DeferQualityUpdatesPeriodInDays"

# Check if the registry path exists
if (Test-Path $regPath) {
    # Try to get the value
    try {
        $value = Get-ItemProperty -Path $regPath -Name $valueName -ErrorAction Stop
        Write-Log "Machiene is Intune Managed.Registry $regPath value found."
        Write-Log "Machiene Defer Quality Updates Period (InDays) = $($value.$valueName)"
    
    } catch {
        Write-Log "Registry key exists, but the value "'$valueName'" was not found.Manually Check Why"
    }
} else {
    Write-Log "Registry path does not exist: $regPath"
}
$newDate = $updateDate.AddDays($($value.$valueName))
$LatestPatchInstallAfter = $updateDate.AddDays($($value.$valueName))
# Output
Write-Log "Latest Patch Release Date: $updateDate"
Write-Log "Script will Install Patch after: $LatestPatchInstallAfter.Try to rerun the remediation after this date."
#Write-Host "Script will Install Patch after: $LatestPatchInstallAfter.Try to rerun the remediation after this date."
Write-Host "Machine is NOT Compliant. Installing update $($latestUpdateInfo.LatestUpdate_KB)"
# Set minimum required NuGet version
    Write-Log "NuGet provider not found or is outdated. Installing/updating..."
    Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force -Scope AllUsers -ForceBootstrap
   #Remove-Item -Path "C:\Program Files\PackageManagement\ProviderAssemblies\nuget" -Recurse -Force
    Write-Log "NuGet Installed/updated..."

$PSWU = Get-Module -Name PSWindowsUpdate -ListAvailable -ErrorAction SilentlyContinue
Write-Log "Checking PSWindowsUpdate module already installed or Not"
If (-not $PSWU) {
    Write-Log "PSWindowsUpdate module not installed.Installing PSWindowsUpdate module..."
    
    Install-Module -Name PSWindowsUpdate -Force -Scope AllUsers
    #Uninstall-Module -Name PSWindowsUpdate -Force -AllVersions
    Import-Module PSWindowsUpdate -Force
    Write-Log "PSWindowsUpdate module already present. Imported..."
} else {
    Write-Log "PSWindowsUpdate module already present. Importing..."
    Import-Module PSWindowsUpdate -Force
    Write-Log "PSWindowsUpdate module already present. Imported..."
}

$ListRequiredUpdate = Get-WindowsUpdate
if($ListRequiredUpdate -eq $null)
    {
        Write-Log "$($latestUpdateInfo.LatestUpdate_KB) is rquired but no updates are reported as missing according to the 'PSWindowsUpdate' module.Exit.."
        Write-Host "$($latestUpdateInfo.LatestUpdate_KB) is rquired but no updates are reported as missing according to the 'PSWindowsUpdate' module.Exit.."
        Exit 1
    }
else
    {
        $titles = ($ListRequiredUpdate | Select-Object -ExpandProperty Title) -join ', '
        Write-Host $titles
        Write-Log $titles
try {
     Write-Log "Installing $($latestUpdateInfo.LatestUpdate_KB)"
     Write-Log "Information: Installing will take 30-35 minutes based on the KB size."
     Get-WindowsUpdate -Install -KBArticleID $latestUpdateInfo.LatestUpdate_KB -IgnoreReboot -MicrosoftUpdate -InformationAction SilentlyContinue -AcceptAll
     Write-Log "$($latestUpdateInfo.LatestUpdate_KB) installed.If not Installed then check machine defer update setting (Current Defer setting: $($value.$valueName))"
     Write-Host "$($latestUpdateInfo.LatestUpdate_KB) is installed. If not, please check the machine's defer update setting. (Current Defer setting: $($value.$valueName))"
         
     Write-Log "Information:-The script will check whether the $($latestUpdateInfo.LatestUpdate_KB) is installed or not in next check. If not, it will try to redetect and reinstall the update."
     Write-Host "$($latestUpdateInfo.LatestUpdate_KB) installed."

    # ==================== Reboot Check =====================
    Start-Sleep 10
    $rebootRequiredKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"
    if (Test-Path $rebootRequiredKey) {
    $rebootGuid = Get-ItemProperty -Path $rebootRequiredKey
    $guidOnly = ($rebootGuid | Get-Member -MemberType NoteProperty | ForEach-Object { $_.Name }) | Where-Object { $_ -match '^[a-f0-9\-]{36}$' }
    if ($guidOnly) {
        Write-Log "Windows Update Reboot pending against GUID: $guidOnly"
        Write-Log "Manual reboot recommended."
        Write-Log "$($latestUpdateInfo.LatestUpdate_KB) installed.Windows Update Reboot pending against GUID: $guidOnly .Manual reboot recommended."
        Write-Host "$($latestUpdateInfo.LatestUpdate_KB) installed.Windows Update Reboot pending against GUID: $guidOnly .Manual reboot recommended."

    }
    
    else 
    
    {
        Write-Log "$($latestUpdateInfo.LatestUpdate_KB) installed .No Windows Update Patching Reboot Required."
        Write-Host "$($latestUpdateInfo.LatestUpdate_KB) installed.No Windows Update Patching Reboot Required."
    }

   } 
   else
   {
    Write-Log "$($latestUpdateInfo.LatestUpdate_KB) installed. No Windows Update Patching Reboot Required."
    Write-Host "$($latestUpdateInfo.LatestUpdate_KB) installed.No Windows Update Patching Reboot Required."
   }
   } catch {
    Write-Log "Failed to install update $($latestUpdateInfo.LatestUpdate_KB): $_"
    Write-Host "Failed to install update $($latestUpdateInfo.LatestUpdate_KB): $_"
    Exit 1
   }
    Write-Log "Intune Patching Remediation Script $(Get-Date -Format 'yyyy/MM/dd') executed successfully."

   Exit 0

}



